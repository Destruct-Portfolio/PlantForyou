### Scraping PlantsForyou 

clients wants to scrape all the images and plan posts description from the the website he wants to save the images into cloudinary
and then save the data into firebase realtime database 


[ ] Scraping 
    - [ ] scrape the plant post information everything 
    - [ ] dowload the image into our local system 

[ ] cloudinary
    - [ ] cloudinary setup 
    - [ ] host our image into cloudinary and get the link back 
    - [ ] delete the folder of the post 

[ ] firebase 
    - [ ] Setup a firebase 
    - [ ] Send data to realtime database

[ ] main script 
    - [ ] will take arguemnt from command line takes a range  200-500 starts from 200 and stops at 500 
    - [ ] scrapes 
    - [ ] saves 
    - [ ] displays finish 

[ ] finalize 
    - [ ] craete docker 
    - [ ] check for dev envirement things 
    - [ ] ship to client 

